console.log("AI Form Filler content script loaded.");

// Extract questions from Google Forms
function getQuestions() {
  return [...document.querySelectorAll(".Qr7Oae")].map(el => el.innerText.trim());
}

// Fill Google Form answers automatically
function fillAnswers(answers) {
  const inputFields = document.querySelectorAll("input[aria-label], textarea[aria-label]");
  answers.forEach((item, i) => {
    if (inputFields[i]) {
      inputFields[i].value = item.answer || "";
      inputFields[i].dispatchEvent(new Event("input", { bubbles: true }));
    }
  });
}

// Fetch AI answers for all questions
async function fetchAnswers() {
  console.log("fetchAnswers started");
  const questions = getQuestions();
  if (!questions.length) {
    console.log("No questions found");
    return;
  }

  let answers = [];
  for (let q of questions) {
    const res = await chrome.runtime.sendMessage({ 
      action: "getAnswer", 
      question: q, 
      allQuestions: questions
    });
    console.log("Answer for", q, ":", res.answer); // <--- Add this line
    answers.push({ question: q, answer: res.answer });
  }

  // Send answers to popup sidebar
  chrome.runtime.sendMessage({ action: "showSidebar", data: answers });

  // Auto-fill answers in the form
  fillAnswers(answers);
  console.log("fetchAnswers finished");
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log("Content script received message:", msg);
  if (msg.action === "fetchAnswers") {
    fetchAnswers().then(() => {
      sendResponse({ status: "done" }); // <-- Add this line
    });
    return true; // <-- Keep the message channel open for async response
  }
});
