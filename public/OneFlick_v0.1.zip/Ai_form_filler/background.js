// Fetch answer from Gemini API
async function queryGemini(prompt, allQuestions) {
  const resumeText = await new Promise((resolve) => {
    chrome.storage.local.get(["resumeText"], (result) => {
      resolve(result.resumeText || "");
    });
  });

  if (!resumeText) {
    console.log("No resume text found in storage.");
    return "⚠️ Paste your resume first";
  }

  // Build context string
  const context = allQuestions && Array.isArray(allQuestions)
    ? `The form has these fields: ${allQuestions.join(", ")}.\n`
    : "";

  try {
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyCm4XoMJPflQtmLfbEoI_DxCAbtp-migUU", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [
          { parts: [{ text: `You are an expert resume parser. Here is a resume:\n${resumeText}\n\n${context}For the form field "${prompt}", extract the most relevant answer from the resume. If the answer is not present, reply with "Not found". Only reply with the answer, nothing else.` }] }
        ]
      })
    });
    const data = await response.json();
    // Gemini returns the answer in data.candidates[0].content.parts[0].text
    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    console.log("Gemini raw text:", JSON.stringify(data.candidates?.[0]?.content));
    const answer = rawText ? rawText.trim() : "";
    return answer && answer.toLowerCase() !== "not found" ? answer : "⚠️ No answer found";
  } catch (err) {
    console.error("Gemini API fetch error:", err);
    return "⚠️ Gemini API error";
  }
}

// Listen for content script messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getAnswer") {
    console.log("background.js: getAnswer for", msg.question);
    queryGemini(msg.question, msg.allQuestions)
      .then(answer => {
        sendResponse({ answer });
      })
      .catch(err => {
        console.error("Error in queryGemini:", err);
        sendResponse({ answer: "⚠️ Gemini API error" });
      });
    return true; // keep channel open for async
  }
});
