// Handle resume submission
document.getElementById("submit-resume").addEventListener("click", () => {
  const resumeText = document.getElementById("resume-text").value.trim();
  if (!resumeText) {
    alert("Please paste your resume first!");
    return;
  }

  // Save resume to chrome storage
  chrome.storage.local.set({ resumeText }, () => {
    alert("Resume submitted successfully!");

    // Ask content script to fetch answers after submitting
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      console.log("Sending fetchAnswers to tab", tabs[0].id);
      chrome.tabs.sendMessage(tabs[0].id, { action: "fetchAnswers" }, (response) => {
        if (chrome.runtime.lastError) {
          console.error("Error sending message to content script:", chrome.runtime.lastError);
        } else {
          console.log("fetchAnswers response:", response);
        }
      });
    });
  });
});

// Receive answers from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "showSidebar") {
    const container = document.getElementById("answers");
    container.innerHTML = "";
    console.log("Sidebar received answers:", msg.data); // <--- Add this line
    msg.data.forEach((item, idx) => {
      const div = document.createElement("div");
      const answerText = item.answer && item.answer.trim() && item.answer.trim().toLowerCase() !== "not found"
        ? item.answer.trim()
        : "⚠️ No answer found";
      div.innerHTML = `
        <b>Q:</b> ${item.question}<br>
        <b>A:</b> <span class="answer-text">${answerText}</span><br>
      `;
      const btn = document.createElement("button");
      btn.textContent = "Copy";
      btn.addEventListener("click", () => {
        copyAnswer(item.answer || "");
      });
      div.appendChild(btn);
      div.appendChild(document.createElement("hr"));
      container.appendChild(div);
      console.log("Rendering answer:", item.answer);
    });
  }
});

function copyAnswer(text) {
  navigator.clipboard.writeText(text);
}
